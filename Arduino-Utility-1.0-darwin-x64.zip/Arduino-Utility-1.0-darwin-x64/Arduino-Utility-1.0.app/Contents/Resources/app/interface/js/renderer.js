const Serialport = require("serialport");
const Readline = require("@serialport/parser-readline");
const app = require("express")();

const server = require("http").createServer(app);
const io = require("socket.io")(server);

const socket = new WebSocket("ws://localhost:3000");

server.listen(3000);

var myPort = "";
var arduinoData = [];

io.on("connection", onConnection);
function onConnection() {
  document.querySelector(".dot.browser").style.background = "rgb(0,255,0)";
}

// List
Serialport.list((err, ports) => {
  console.log("ports", ports);
  if (err) {
    document.getElementById("error").textContent = err.message;
    return;
  } else {
    document.getElementById("error").textContent = "";
  }

  if (ports.length === 0) {
    document.getElementById("error").textContent = "No ports discovered";
  }

  // let listPorts = [];
  for (let i = 0; i < ports.length; i++) {
    document.getElementById("select-port").innerHTML +=
      '<option value="' + i + '">' + ports[i].comName + "</option>";
  }

  document.getElementById("select-port").onchange = function () {
    document.getElementById("data").innerHTML = "";
    if (ArduinoPort) {
      ArduinoPort.close(function (err) {
        console.log("port closed", err);
      });
    }
    myPort = ports[this.value].comName;

    var ArduinoPort = new Serialport(myPort, {
      baudRate: 9600,
    });
    const parser = ArduinoPort.pipe(new Readline({ delimiter: "\r\n" }));

    ArduinoPort.on("open", function () {
      document.getElementById("data").innerHTML = "open";
      document.querySelector(".dot.arduino").style.background = "rgb(0,255,0)";
      parser.on("data", dataText);
      function dataText(event) {
        arduinoData = event.split("\t");
        // console.log(arduinoData);

        io.emit("data", { arduinodata: arduinoData });

        document.getElementById("data").innerHTML = "";
        for (let i = 0; i < arduinoData.length; i++) {
          document.getElementById("data").innerHTML +=
            "\n" + arduinoData[i] + "<br>";
        }
      }
    });

    ArduinoPort.on("error", function () {
      console.log("Can't establish serial connection with " + process.argv[2]);
      document.body.style.background = "red";
      document.body.innerHTML =
        "<h1 id='reload'>This is not an Arduino port. Reload the page by typing :<br>For MacOs &#8984; + R <br>For Windows ctrl + R <h1>";
      //   process.exit(1);
    });

    ArduinoPort.on("close", () => ArduinoPort.open());
  };
});
